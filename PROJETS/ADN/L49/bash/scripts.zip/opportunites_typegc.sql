SET CLIENT_ENCODING TO 'UTF8';
\copy (SELECT * FROM rapport.opportunites_typegc) TO '/home/scripts/rapport_ADN/opportunites_typegc.csv'  DELIMITER ';' CSV HEADER;

