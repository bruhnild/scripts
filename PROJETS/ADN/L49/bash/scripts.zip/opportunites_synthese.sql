SET CLIENT_ENCODING TO 'UTF8';
\copy (SELECT * FROM rapport.opportunites_synthese) TO '/home/scripts/rapport_ADN/opportunites_synthese.csv'  DELIMITER ';' CSV HEADER;

